Verlass 2.0.0 for Gmail: Private install
A help desk in the Gmail side panel. By Alyssa I. Agard.
https://verlass.alyssaagard.dev

WHAT IS IN THIS PACKAGE

  service/   The help desk service: Core.gs, Service.gs, Store.gs, and
             appsscript.json. It owns the Google Sheet and sends the email.
             It runs as one account, ideally a shared one such as
             helpdesk@your-domain.
  addon/     The add-on people install: Addon.gs, Cards.gs, Core.gs,
             SettingsCards.gs, and appsscript.json. It asks staff only to
             run in Gmail, know their email address, and reach the service.
  LICENSE.txt The MIT License, which lets you use, change, and share
             Verlass. Keep it with any copy you pass on.
  README.txt This guide.

In this install the Google Sheet is shared with no one but its owner. The
add-on proves who each person is with a Google sign-in token, and the service
answers only for that person. Staff see only their own requests.

Version 2.0.0 is new. It has been tested against a simulated Gmail and
Google Sheets, and has not yet been run in a live Google account. Try it with
a few people first.

PART 1: THE SERVICE

  Sign in to Google as the account that should own the help desk.
  1. Go to script.google.com, select New project, and rename it
     Verlass service.
  2. Select Project Settings (the gear) and check
     Show "appsscript.json" manifest file in editor.
  3. In the Editor, add the script files Core, Service, and Store (the plus
     sign next to Files, then Script) and paste in the matching .gs files from
     the service folder. Delete the starter file Code.gs. Replace everything
     in appsscript.json with the one in the service folder, and change
     America/New_York to your time zone if needed. Save.
  4. Select Deploy, then New deployment. Choose the type Web app. Set
     Execute as to Me and Who has access to Anyone. Select Deploy and approve
     the permissions. With a free Gmail account, Google first says that it
     has not verified this app, because the project is your own. Select
     Advanced, then Go to Verlass service (unsafe).
  5. Copy the Web app URL. It ends in /exec.
  6. Recommended for Google Workspace: in Project Settings, under Script
     properties, add a property named ALLOWED_DOMAIN with your organization's
     primary domain, for example example.org. That is the domain shown first
     in the Google Admin console under Account, Domains, even when people use
     addresses at another of its domains. Separate several with commas. The
     service then refuses accounts from anywhere else. Do not set it for free
     Gmail accounts, which have no organization domain.

PART 2: THE ADD-ON

  1. Create a second project and rename it Verlass. Show the manifest file as
     before.
  2. Add the script files Addon, Cards, Core, and SettingsCards and paste in
     the matching .gs files from the addon folder. Delete Code.gs. Replace
     appsscript.json with the one in the addon folder. Save.
  3. In Project Settings, under Script properties, add a property named
     SERVICE_URL and paste the web app URL from Part 1.
  4. Select Deploy, then Test deployments, then Install, then Done.
  5. Open Gmail as the owner account, open Verlass, authorize it, and select
     Create the help desk. The first time the owner or an administrator opens
     the add-on, the service remembers this add-on project and refuses
     requests from any other.
  6. Open Settings, then Team, and add your team.

WHY THE WEB APP IS OPEN TO "ANYONE"

  The add-on reaches the service over the internet, so Google must let the
  request in. The service then checks every request itself: it must carry a
  Google sign-in token for a verified account, from your domain if you set
  ALLOWED_DOMAIN, issued to your own add-on project. A request without those
  gets an error and nothing else. If your organization does not allow web
  apps that are open to anyone, use the Standard install.

OTHER PEOPLE

  For a few trusted people, share the add-on project (never the service
  project) with them as Editor and have each one do step 4 of Part 2, then
  open Verlass in Gmail and authorize it.
  Anyone who can edit the add-on project can change its code and could act as
  another person, so do not share it with ordinary staff. For them, publish
  the add-on project in the Google Workspace Marketplace for your
  organization only. The steps are at
  https://verlass.alyssaagard.dev/install/#gmail-organization
  Publish before people start using the help desk. Moving the add-on project
  to a Google Cloud project is expected to change the identity the service
  remembers. If people then see "made for a different add-on", delete the
  script property ALLOWED_AUDIENCE in the service project and have the owner
  open the add-on first.

UPDATES AND HELP

  When a new version comes out, replace the script files in both projects.
  In the service project, select Deploy, then Manage deployments, edit the
  web app, and choose New version, so its address stays the same. If you
  published the add-on for your organization, edit its add-on deployment the
  same way.
  Every email notice comes from the owner's account. Google limits it to
  about 100 recipients a day for a free account and 1,500 for a Google
  Workspace account.
  Only the time zone in the service project's appsscript.json matters; the
  add-on shows times the way the service does.
  Help: https://verlass.alyssaagard.dev/help/
