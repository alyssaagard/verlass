Verlass 2.0.1 for Gmail: Standard install
A help desk in the Gmail side panel. By Alyssa I. Agard.
https://verlass.alyssaagard.dev

WHAT IS IN THIS PACKAGE

  Addon.gs          Opens Verlass in Gmail and connects it to the help desk.
  Cards.gs          The screens: new request, lists, and one ticket.
  SettingsCards.gs  The settings screens for administrators.
  Service.gs        The help desk itself: who may do what, and the email.
  Store.gs          Reads and writes the help desk's Google Sheet.
  Core.gs           The rules shared with Verlass for Outlook.
  appsscript.json   The project settings and the permissions it asks for.
  LICENSE.txt       The MIT License, which lets you use, change, and share
                    Verlass. Keep it with any copy you pass on.
  README.txt        This guide.

Everything runs in your own Google account. Tickets and settings are rows in
one Google Sheet in your Drive. Verlass has no server and no tracking.

In this Standard install, everyone who uses the help desk needs edit access to
that Sheet. That is fine for one person or a small team that trusts each
other. For an organization, use the Private install instead
(verlass-gmail-private.zip), which keeps the Sheet closed.

INSTALL

  1. Go to script.google.com, select New project, and rename it Verlass.
  2. Select Project Settings (the gear) and check
     Show "appsscript.json" manifest file in editor.
  3. Back in the Editor, for each of Addon, Cards, Core, Service,
     SettingsCards, and Store: select the plus sign next to Files, choose
     Script, type the name, and replace everything in the new file with the
     contents of the matching .gs file from this package.
     Then delete the starter file Code.gs.
  4. Open appsscript.json and replace everything in it with this package's
     appsscript.json. If you are not in the US Eastern time zone, change
     America/New_York to yours, for example Europe/Berlin. Save.
  5. Select Deploy, then Test deployments, then Install, then Done.
  6. Open Gmail and reload it. Select the Verlass icon in the panel on the
     right, select Authorize access, and approve the permissions.
     With a free Gmail account, Google first says that it has not verified
     this app, because the project is your own. Select Advanced, then
     Go to Verlass (unsafe).
  7. Enter your organization's name, choose a starting set of lists, and
     select Create the help desk. You become the first administrator.
  8. Open Settings, then Team, and add the people who work on tickets.
     Select Open the spreadsheet and share the Sheet, as Editor, with everyone
     who will use the help desk.

OTHER PEOPLE

  A test deployment is installed per person, and Google lets a person install
  it only if they can edit the project. In Google Workspace they must also
  belong to the owner's organization. Anyone who can edit the project can
  change what it does, so share it only with people you would trust as
  administrators, and have each one do steps 5 and 6. Sharing between free
  Gmail accounts has not been tested.
  For everyone else, publish the add-on in the Google Workspace Marketplace
  for your organization only. The steps are at
  https://verlass.alyssaagard.dev/install/#gmail-organization

UPLOAD WITH CLASP (for IT teams and developers)

  1. Turn on the Apps Script API at script.google.com/home/usersettings.
  2. npm install -g @google/clasp   then   clasp login
  3. In an empty folder:
     clasp create-script --type standalone --title "Verlass"
  4. Copy this package's files into the folder. Delete any Code.js file that
     clasp made, and let this package's appsscript.json replace clasp's.
  5. clasp push --force   then   clasp open-script
     and continue from step 5 above.
  Versions of clasp before 3 call these commands clasp create and clasp open.

CREATE A TICKET FROM THE OPEN EMAIL (optional)

  This needs one more permission, so it is off by default. The steps are at
  https://verlass.alyssaagard.dev/install/#gmail-email

UPDATES AND HELP

  Add-ons installed this way do not update themselves. When a new version
  comes out, replace the script files with the new package's files. Your
  Sheet and your settings are not touched. If you published the add-on for
  your organization, also select Deploy, then Manage deployments, edit the
  add-on deployment, and choose New version.
  Google limits the email an account sends through Apps Script to about 100
  recipients a day for a free account and 1,500 for a Google Workspace
  account.
  Help: https://verlass.alyssaagard.dev/help/
