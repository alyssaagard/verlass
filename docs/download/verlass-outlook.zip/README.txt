Verlass 2.0.1 for Outlook
A help desk in the Outlook side panel. By Alyssa I. Agard.
https://verlass.alyssaagard.dev

WHAT IS IN THIS PACKAGE

  verlass-manifest.xml  The add-in manifest. It tells Outlook where Verlass
                        lives and what it may do. It holds no program code.
                        This copy has no connection settings yet (see below).
  LICENSE.txt           The MIT License, which lets you use, change, and share
                        Verlass. Keep it with any copy you pass on.
  README.txt            This guide.

Verlass for Outlook works in Outlook on the web, the new and classic Outlook
for Windows, Outlook for Mac, and Outlook for iOS and Android, with Microsoft
365 work or school accounts. Tickets are items in a SharePoint list in your
own tenant. Verlass has no server and no tracking.

Version 2.0.1 is new. The Outlook add-in has been tested against a
simulated Microsoft 365, not yet in a live tenant. Try it with a few people
first.

THE EASY WAY

  Follow the steps at https://verlass.alyssaagard.dev/install/#outlook
  That page makes a manifest with your organization's settings already in it.

BY HAND

  An administrator does this once. A Global Administrator can do every step;
  the install page lists narrower roles. Whoever creates the lists must be an
  Owner of the help desk site.
  1. Create a private SharePoint team site for the help desk. Make the help
     desk team Owners of the site. Under the gear, Site permissions, Advanced
     permissions settings, open the Visitors group and add
     "Everyone except external users". Do not add staff as Members.
  2. In the Microsoft Entra admin center, under App registrations, select
     New registration. Name it Verlass, keep "Accounts in this organizational
     directory only", and add these three redirect URIs, all of the type
     Single-page application (SPA):
       brk-multihub://verlass.alyssaagard.dev
       https://verlass.alyssaagard.dev/app/blank.html
       https://verlass.alyssaagard.dev/app/auth.html
  3. Under API permissions, add the Microsoft Graph delegated permissions
     Sites.Selected and Mail.Send (User.Read is already there), then select
     Grant admin consent.
  4. Open verlass-manifest.xml in a text editor. Find every place that says
       https://verlass.alyssaagard.dev/app/outlook.html
     (there are three) and add your settings to the end of each, on one
     line, like this:
       https://verlass.alyssaagard.dev/app/outlook.html?client=APPLICATION-ID&amp;tenant=TENANT-ID&amp;site=https%3A%2F%2Fcontoso.sharepoint.com%2Fsites%2Fhelpdesk
     Keep the &amp; between the parts, and write the site address with %3A
     for each colon and %2F for each slash.
  5. Open https://verlass.alyssaagard.dev/app/
     in a browser, enter the same three values, and sign in. Open
     "I am the administrator" and select "1. Create the lists". Microsoft
     asks you to approve one higher permission, Sites.FullControl.All. Leave
     "Consent on behalf of your organization" unchecked. Then enter your
     organization's name and select "2. Create the help desk".
     Afterward remove that permission again. The Entra admin center cannot
     remove one person's consent, so use Graph Explorer as the install page
     describes: https://verlass.alyssaagard.dev/install/#outlook-revoke
  6. Set who can see what. On the site, under Site contents:
     Help Desk Tickets: in List settings, Advanced settings, Item-level
       Permissions, choose "Read items that were created by the user" and
       "Create items and edit items that were created by the user". In
       Permissions for this list, stop inheriting permissions and grant
       "Everyone except external users" the level Contribute.
     Help Desk Notes: in Permissions for this list, stop inheriting
       permissions and remove every group except the Owners.
     Help Desk Settings: leave it as it is.
  7. In the Microsoft 365 admin center, go to Settings, then Integrated apps.
     Select Upload custom apps, choose Office Add-in as the app type, upload
     the manifest, choose who gets it, and finish the deployment. It can take
     up to 24 hours to appear, sometimes longer.
  8. Open Verlass in Outlook, open the menu, choose Settings, then Lists, then
     Team, and add the people who work on tickets.

FOR ONE PERSON, OR TO TEST FIRST

  In Outlook on the web, open https://aka.ms/olksideload, choose My add-ins,
  then Add a custom add-in, then Add from File, and choose the manifest.

UPDATES AND HELP

  Outlook loads Verlass from its website each time it opens, so there is
  nothing to reinstall when a new version comes out.
  Help: https://verlass.alyssaagard.dev/help/
